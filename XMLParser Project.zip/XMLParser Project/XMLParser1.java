import java.io.Console;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLParser1 {

	public static void main(String[] args) throws IOException {
		File file = null;
		DocumentBuilder dBuilder = null;
		FileWriter fw=null;
		try {
			String fileName = args[0];
			String nodeNames = args[1];
			String outputfile = args[2];

			file = new File(fileName);// "C:\\Manjula\\test.xml
			dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			fw = new FileWriter(outputfile);
			fw.write("Program Input " + Arrays.toString(args)+"\n"); //opening the output file and writing all the three arguments entered by user

			for (int i = 0; i< nodeNames.split(" ").length; i++) {
				Document doc = dBuilder.parse(file);

				if (doc.hasChildNodes()) {
					System.out.println("Console output:" + checkforNode(doc.getChildNodes(), nodeNames.split(" ")[i], ""));
					fw.write("Console output:" + checkforNode(doc.getChildNodes(), nodeNames.split(" ")[i], "")+"\n");
				}
			}
			do {
				Console console = System.console();
				nodeNames = console.readLine("Console input:");
				fw.write("Console input:" + nodeNames+"\n");
				for (int i= 0; i< nodeNames.split(" ").length; i++) {
					Document doc = dBuilder.parse(file);

					if (doc.hasChildNodes()) {
						System.out.println("Console output:" + checkforNode(doc.getChildNodes(), nodeNames.split(" ")[i], ""));
						fw.write("Console output:" + checkforNode(doc.getChildNodes(), nodeNames.split(" ")[i], "")+"\n");
					}
				}
			} while (true);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				fw.close();
				file=null;
				dBuilder=null;
			}
		 catch (Exception e) {
				System.out.println(e.getMessage());
			} 
		}

	}

	private static String checkforNode(NodeList nodeList, String nodeName, String result) {

		for (int i= 0; i< nodeList.getLength(); i++) {

			Node tempNode = nodeList.item(i);
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {
				if (tempNode.getNodeName().equals(nodeName)) {
					result += " " + tempNode.getTextContent();
				}
				if (tempNode.hasChildNodes()) {
					String temp = checkforNode(tempNode.getChildNodes(), nodeName, "");
					result += temp.trim().equals("") ? "" : " " + temp;

				}

			}

		}
		return result;

	}

}
