

public class FizzBuzz {	
				public static void main(String[] args ) {
				int P1=Integer.parseInt(args[0]);
			    int D1=Integer.parseInt(args[1]);
			    int D2=Integer.parseInt(args[2]);
				System.out.println("Input parameters("+P1+", "+D1+", "+D2+")");
				for(int index=1; index <=P1; index++) {
					if(index%D1==0 && index%D2==0) {System.out.println("FizzBuzz");}
					else if(index%D1==0) {System.out.println("Fizz");}
					else if(index%D2==0) {System.out.println("Buzz");}
					else {System.out.println(index);}
					}
				}
		}



